﻿# Kiydroid PC installer: installs the app on a phone over USB and turns on device management.
# Runs on Windows PowerShell 5.1 (built into Windows 10/11). Started by Install-Kiydroid.bat.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Here    = Split-Path -Parent $MyInvocation.MyCommand.Path
$Work    = Join-Path $env:LOCALAPPDATA 'Kiydroid'
$Pkg     = 'com.kdroid.filter'
$ApkUrl  = 'https://raw.githubusercontent.com/EliyahuHillel/kdroid-updates/main/kdroid.bin'
$AdbUrl  = 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip'

# The same activation command the app runs in its own one-tap setup (AdbSetupActivity.ACTIVATE_ALL):
# account apps are paused for a moment so device management can be turned on, then restored.
$Activate = @'
A=$(cmd package query-services -a android.accounts.AccountAuthenticator | grep packageName | cut -d '=' -f 2 | tr -d '\r' | sort -u | grep -viE 'bluetooth|telecom|telephony|dialer|contacts|phonebook|calendar|carservice|car.')
echo "$A" | sed 's/^/pm disable-user --user 0 /' | sh
sleep 3
dpm set-device-owner com.kdroid.filter/.listener.AdminListener
appops set com.kdroid.filter ACTIVATE_VPN allow
pm grant com.kdroid.filter android.permission.POST_NOTIFICATIONS
appops set com.kdroid.filter SYSTEM_ALERT_WINDOW allow
appops set com.kdroid.filter GET_USAGE_STATS allow
echo "$A" | sed 's/^/pm enable /' | sh
pm enable com.google.android.gms
pm enable com.google.android.gsf
pm enable com.android.vending
'@

# ------------------------------------------------------------------ window
$Green = [System.Drawing.Color]::FromArgb(0, 108, 81)
$Muted = [System.Drawing.Color]::FromArgb(64, 73, 68)
$Bg    = [System.Drawing.Color]::FromArgb(251, 253, 249)

$form = New-Object System.Windows.Forms.Form
$form.Text = 'התקנת קיידרואיד'
$form.Size = New-Object System.Drawing.Size(620, 680)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.RightToLeft = 'Yes'
$form.RightToLeftLayout = $true
$form.BackColor = $Bg
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'התקנת קיידרואיד בטלפון'
$title.Font = New-Object System.Drawing.Font('Segoe UI', 17, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = $Green
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(24, 18)
$form.Controls.Add($title)

$steps = New-Object System.Windows.Forms.Label
$steps.Text = "לפני שמתחילים, בטלפון:`r`n" +
  "1. הגדרות ← אודות הטלפון ← הקישו 7 פעמים על 'מספר גרסה', עד שמופיע 'אתה מפתח'.`r`n" +
  "2. הגדרות ← אפשרויות מפתח ← הפעילו 'ניפוי באגים ב-USB'.`r`n" +
  "3. חברו את הטלפון למחשב בכבל, ואשרו בטלפון את ההודעה 'לאפשר ניפוי באגים'.`r`n" +
  "אחר כך לחצו 'התקן', והכל יתבצע לבד."
$steps.ForeColor = $Muted
$steps.Location = New-Object System.Drawing.Point(24, 64)
$steps.Size = New-Object System.Drawing.Size(560, 112)
$form.Controls.Add($steps)

$onlyInstall = New-Object System.Windows.Forms.CheckBox
$onlyInstall.Text = 'להתקין בלבד, בלי להפעיל ניהול מכשיר'
$onlyInstall.ForeColor = $Muted
$onlyInstall.AutoSize = $true
$onlyInstall.Location = New-Object System.Drawing.Point(24, 182)
$form.Controls.Add($onlyInstall)

$go = New-Object System.Windows.Forms.Button
$go.Text = 'התקן'
$go.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
$go.BackColor = $Green
$go.ForeColor = [System.Drawing.Color]::White
$go.FlatStyle = 'Flat'
$go.FlatAppearance.BorderSize = 0
$go.Size = New-Object System.Drawing.Size(560, 46)
$go.Location = New-Object System.Drawing.Point(24, 214)
$form.Controls.Add($go)

$status = New-Object System.Windows.Forms.Label
$status.Text = 'מוכן להתקנה.'
$status.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
$status.Location = New-Object System.Drawing.Point(24, 274)
$status.Size = New-Object System.Drawing.Size(560, 26)
$form.Controls.Add($status)

$log = New-Object System.Windows.Forms.RichTextBox
$log.ReadOnly = $true
$log.RightToLeft = 'Yes'
$log.BackColor = [System.Drawing.Color]::White
$log.BorderStyle = 'FixedSingle'
$log.Location = New-Object System.Drawing.Point(24, 306)
$log.Size = New-Object System.Drawing.Size(560, 318)
$form.Controls.Add($log)

function Pump { [System.Windows.Forms.Application]::DoEvents() }
function Say([string]$text, [string]$color = 'black') {
  $log.SelectionStart = $log.TextLength
  $log.SelectionColor = [System.Drawing.Color]::FromName($color)
  $log.AppendText($text + "`r`n")
  $log.ScrollToCaret()
  Pump
}
function Step([string]$text) { $status.ForeColor = $Green; $status.Text = $text; Say ('• ' + $text) 'DarkGreen' }
function Fail([string]$text) { $status.ForeColor = [System.Drawing.Color]::Firebrick; $status.Text = 'ההתקנה לא הושלמה'; Say $text 'Firebrick'; throw 'stop' }

# ------------------------------------------------------------------ helpers
function Run([string]$exe, [string]$arguments, [int]$timeoutSec = 180) {
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $exe
  $psi.Arguments = $arguments
  $psi.UseShellExecute = $false
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.CreateNoWindow = $true
  $p = [System.Diagnostics.Process]::Start($psi)
  $outTask = $p.StandardOutput.ReadToEndAsync()
  $errTask = $p.StandardError.ReadToEndAsync()
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  while (-not $p.HasExited) {
    Start-Sleep -Milliseconds 100; Pump
    if ($sw.Elapsed.TotalSeconds -gt $timeoutSec) { try { $p.Kill() } catch {}; return @{ Code = -1; Out = 'timeout' } }
  }
  return @{ Code = $p.ExitCode; Out = ($outTask.Result + $errTask.Result).Trim() }
}

function Download([string]$url, [string]$file) {
  $wc = New-Object System.Net.WebClient
  $task = $wc.DownloadFileTaskAsync($url, $file)
  while (-not $task.IsCompleted) { Start-Sleep -Milliseconds 150; Pump }
  if ($task.IsFaulted) { throw $task.Exception.InnerException }
}

function Get-Adb {
  $local = Join-Path $Here 'platform-tools\adb.exe'
  if (Test-Path $local) { return $local }
  $cached = Join-Path $Work 'platform-tools\adb.exe'
  if (Test-Path $cached) { return $cached }
  Step 'מוריד את כלי החיבור של Google (פעם אחת בלבד)…'
  New-Item -ItemType Directory -Force -Path $Work | Out-Null
  $zip = Join-Path $Work 'platform-tools.zip'
  try { Download $AdbUrl $zip } catch { Fail 'לא הצלחתי להוריד את כלי החיבור. בדקו שיש אינטרנט במחשב ונסו שוב.' }
  Expand-Archive -Path $zip -DestinationPath $Work -Force
  Remove-Item $zip -Force
  if (-not (Test-Path $cached)) { Fail 'כלי החיבור לא נמצא אחרי ההורדה.' }
  return $cached
}

function Get-Apk {
  $local = Get-ChildItem -Path $Here -Filter '*.apk' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($local) { Say ('משתמש בקובץ שבתיקייה: ' + $local.Name); return $local.FullName }
  Step 'מוריד את הגרסה העדכנית של קיידרואיד…'
  New-Item -ItemType Directory -Force -Path $Work | Out-Null
  $apk = Join-Path $Work 'kiydroid.apk'
  try { Download ($ApkUrl + '?t=' + [DateTime]::UtcNow.Ticks) $apk } catch { Fail 'לא הצלחתי להוריד את קיידרואיד. בדקו שיש אינטרנט במחשב ונסו שוב.' }
  return $apk
}

function Wait-Device([string]$adb) {
  Step 'מחפש טלפון מחובר…'
  Run $adb 'start-server' 60 | Out-Null
  $warned = $false
  for ($i = 0; $i -lt 120; $i++) {
    $r = Run $adb 'devices' 20
    $lines = @($r.Out -split "`n" | Where-Object { $_ -match "`t" })
    $ready = @($lines | Where-Object { $_ -match "`tdevice\s*$" })
    if ($ready.Count -gt 1) { Fail 'מחוברים כמה מכשירים. השאירו מחובר רק את הטלפון שמתקינים בו ונסו שוב.' }
    if ($ready.Count -eq 1) { Say 'הטלפון מחובר.'; return }
    if (-not $warned -and ($lines -match 'unauthorized')) {
      Say 'בטלפון מופיעה הודעה "לאפשר ניפוי באגים?". סמנו "אפשר תמיד מהמחשב הזה" ולחצו "אישור".' 'DarkOrange'; $warned = $true
    }
    Start-Sleep -Milliseconds 500; Pump
  }
  Fail ("לא נמצא טלפון מחובר.`r`n" +
        "• בדקו שהכבל מעביר נתונים (לא רק טעינה) ושניפוי באגים ב-USB פעיל.`r`n" +
        "• בחלק מהטלפונים צריך להתקין במחשב את מנהל ההתקן (Driver) של היצרן.")
}

function Is-Owner([string]$adb) {
  $r = Run $adb 'shell dumpsys device_policy' 60
  return ($r.Out -match 'Device Owner' -and $r.Out -match $Pkg)
}

# ------------------------------------------------------------------ install
function Install-All {
  $log.Clear()
  New-Item -ItemType Directory -Force -Path $Work | Out-Null
  $adb = Get-Adb
  $apk = Get-Apk
  Wait-Device $adb

  $model = (Run $adb 'shell getprop ro.product.model' 20).Out
  $sdk = (Run $adb 'shell getprop ro.build.version.sdk' 20).Out
  Say ("מכשיר: " + $model + " · אנדרואיד API " + $sdk)

  Step 'מתקין את קיידרואיד בטלפון…'
  $r = Run $adb ('install -r -g "' + $apk + '"') 300
  if ($r.Out -notmatch 'Success') {
    if ($r.Out -match 'UPDATE_INCOMPATIBLE|SIGNATURES') {
      Fail ("בטלפון מותקנת גרסה אחרת של קיידרואיד, שחתומה אחרת. צריך להסיר אותה קודם.`r`n" +
            "אם ההסרה חסומה (ניהול מכשיר פעיל), שחררו את המכשיר מהפאנל או בקוד חירום, ואז הסירו.`r`n" + $r.Out)
    }
    if ($r.Out -match 'VERSION_DOWNGRADE') { Fail ("בטלפון מותקנת כבר גרסה חדשה יותר. אין צורך להתקין.`r`n" + $r.Out) }
    if ($r.Out -match 'INSUFFICIENT_STORAGE') { Fail 'אין מספיק מקום פנוי בטלפון.' }
    Fail ("ההתקנה נכשלה:`r`n" + $r.Out)
  }
  Say 'האפליקציה הותקנה.'

  if (-not $onlyInstall.Checked) {
    if (Is-Owner $adb) {
      Say 'ניהול המכשיר כבר פעיל. אין צורך להפעיל שוב.'
    } else {
      Step 'מפעיל ניהול מכשיר ונותן הרשאות…'
      $sh = Join-Path $Work 'kd-activate.sh'
      [IO.File]::WriteAllText($sh, ($Activate -replace "`r`n", "`n"), (New-Object System.Text.UTF8Encoding($false)))
      Run $adb ('push "' + $sh + '" /data/local/tmp/kd-activate.sh') 60 | Out-Null
      $r = Run $adb 'shell sh /data/local/tmp/kd-activate.sh' 180
      Run $adb 'shell rm -f /data/local/tmp/kd-activate.sh' 30 | Out-Null
      if (-not (Is-Owner $adb)) {
        if ($r.Out -match 'already some accounts|accounts on the device') {
          Fail ("לא ניתן להפעיל ניהול מכשיר כי יש בטלפון חשבונות שלא ניתן להשהות.`r`n" +
                "הסירו את החשבונות (הגדרות ← חשבונות), לחצו שוב 'התקן', ואחר כך אפשר להוסיף אותם בחזרה.")
        }
        if ($r.Out -match 'several users|already provisioned|is already set|device owner is already') {
          Fail ("לא ניתן להפעיל ניהול מכשיר: בטלפון יש משתמש נוסף, פרופיל עבודה, או אפליקציית ניהול אחרת.`r`n" + $r.Out)
        }
        Fail ("הפעלת ניהול המכשיר נכשלה:`r`n" + $r.Out)
      }
      Say 'ניהול המכשיר הופעל.'
    }
  }

  Step 'פותח את קיידרואיד בטלפון…'
  Run $adb ('shell am start -n ' + $Pkg + '/.MainActivity') 30 | Out-Null
  $status.ForeColor = $Green
  $status.Text = 'ההתקנה הושלמה ✓'
  Say ''
  Say 'ההתקנה הושלמה. המשיכו בטלפון: מלאו שם וטלפון, ושלחו בקשה להפעלת הסינון.' 'DarkGreen'
  Say 'מומלץ לכבות עכשיו את ניפוי הבאגים ב-USB. קיידרואיד גם יחסום אותו בעצמו לאחר ההפעלה.' 'DimGray'
}

$go.Add_Click({
  $go.Enabled = $false; $onlyInstall.Enabled = $false
  try { Install-All } catch { if ("$_" -ne 'stop') { $status.ForeColor = [System.Drawing.Color]::Firebrick; $status.Text = 'ההתקנה לא הושלמה'; Say ('שגיאה: ' + $_) 'Firebrick' } }
  $go.Text = 'התקן שוב'; $go.Enabled = $true; $onlyInstall.Enabled = $true
})

[void]$form.ShowDialog()
